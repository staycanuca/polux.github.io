# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://serialehdnoi.com'

class serialehdnoi:
    
    thumb = os.path.join(media, 'serialehdnoi.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'SerialeHDNoi.com'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Genuri', base_url, 'genuri', thumb),
            ('Filme', base_url + '/filme', 'filme', thumb),
            ('Seriale', base_url + '/seriale', 'filme', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword, result):
        result.append((self.__class__.__name__, self.name, self.parse_menu('post', 'cauta', keyw=keyword)))

    def parse_menu(self, url, meniu, info={}, keyw=''):
        lists = []
        imagine = ''
        if meniu == 'filme' or meniu == 'cauta':
            regex_menu = '''<article(.+?)</arti'''
            if meniu == 'cauta':
                if url == 'post' and keyw:
                    regex_submenu = '''src="(.+?)".+?movies">(.+?)<.+?href="(.+?)">(.+?)<.+?year">(.+?)<.+?contenido">(.+?)</div'''
                    link = fetchData(self.get_search_url(keyw))
                else:
                    link = None
                    from resources.Core import Core
                    Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url)
                regex_submenu = '''src="(.+?)".+?(?:quality">(.+?)<.+?)?href="(.+?)".+?title">(.+?)</div.+?imdb">(.+?)<.+?(\d{4}).+?texto">(.+?)</div(?:.+?genres">(.+?)</div)?'''
            if link:
                for movie in re.compile(regex_menu, re.DOTALL).findall(link):
                    match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                    if meniu == 'filme':
                        for imagine, calitate, legatura, nume, rating, an, descriere, genres in match:
                            nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                            nume = '%s (%s)' % (nume, str(an))
                            rating = str(re.findall('(\d(?:.\d)?)', rating)[0])
                            info = {'Title': nume,'Plot': descriere,'Poster': imagine,'Year': str(an), 'Rating': rating}
                            if descriere:
                                descriere = (htmlparser.HTMLParser().unescape(striphtml(descriere).decode('utf-8')).encode('utf-8')).strip()
                                info['Plot'] = descriere
                            if genres:
                                genre = ", ".join(re.findall('tag">(.+?)<', genres, re.DOTALL))
                                info['Genre'] = genre
                            if re.search('/sezoane|episoade|seriale/', legatura):
                                lists.append((nume + ' - Serial', legatura, imagine, 'episoade', str(info)))
                            else:
                                lists.append((nume, legatura, imagine, 'get_links', str(info)))
                    else:
                        for imagine, tip, legatura, nume, an, descriere in match:
                            nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                            nume = '%s (%s)' % (nume, an.strip())
                            descriere = (htmlparser.HTMLParser().unescape(striphtml(descriere).decode('utf-8')).encode('utf-8')).strip()
                            info = {'Title': nume,'Plot': nume,'Poster': imagine}
                            lists.append((nume, legatura, imagine, 'get_links', str(info)))
                match = re.compile('"pagination"', re.IGNORECASE).findall(link)
                if len(match) > 0:
                    if '/page/' in url:
                        new = re.compile('/page/(\d+)').findall(url)
                        nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                    else:
                        if '/?s=' in url:
                            nextpage = re.compile('\?s=(.+?)$').findall(url)
                            nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                        else: nexturl = url + "/page/2"
                    lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_links':
            link = fetchData(url)
            regex_lnk = '''<iframe.+?src="((?:[htt]|[//]).+?)"'''
            regex_infos = '''"description">(.+?)</'''
            match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
            match_nfo = re.compile(regex_infos, re.IGNORECASE | re.DOTALL).findall(link)
            try:
                info = eval(str(info))
                info['Plot'] = (striphtml(match_nfo[0]).strip())
            except: pass
            for host, link1 in get_links(match_lnk):
                lists.append((host,link1,'','play', str(info), url))
        elif meniu == 'recente':
            regex_menu = '''<article(.+?)</arti'''
            regex_submenu = '''(?:(?:"item se episodes".+?src="(.+?)".+?href="(.+?)">.+?quality">(.+?)<.+?serie">(.+?)<.+?"></div>(.+?)</div)|(?:"item".+?src="(.+?)".+?href="(.+?)".+?title">(.+?)</div))'''
            link = fetchData(url)
            for movie in re.compile(regex_menu, re.DOTALL).findall(link):
                match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                for res in match:
                    if res[0]: imagine = res[0]
                    elif res[5]: imagine = res[5]
                    if res[1]: legatura = res[1]
                    elif res[6]: legatura = res[6]
                    if res[3]: nume = res[3]
                    elif res[7]: nume = res[7]
                    numeepisod = res[4]
                    #nume2 = res[5] = res[10]
                    calitate = res[2]
                    
                    nume = (htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')).strip()
                    try: nume = re.sub(r'(\d{4})', r'(\1)', " ".join(re.split('((?:19|20)\d{2})', nume)))
                    except: pass
                    info = {'Title': nume,'Plot': nume,'Poster': imagine}
                    if re.search('/sezoane|episoade/|/seriale/', legatura):
                        lists.append((nume + ' - Serial', legatura, imagine, 'episoade', str(info)))
                    else:
                        lists.append((nume, legatura, imagine, 'get_links', str(info)))
        elif meniu == 'episoade':
            import codecs
            import unicodedata
            link = fetchData(url)
            regex_menu = '''serie_contenido"(.+?)jQuery'''
            regex_submenu = '''src="(.+?)".+?numerando">(.+?)<.+?href="(.+?)">(.+?)<.+?date">(.+?)<'''
            info = json.loads(info)
            title = info.get('Title')
            for serial in re.compile(regex_menu, re.DOTALL | re.IGNORECASE).findall(link):
                match = re.compile(regex_submenu, re.DOTALL).findall(serial)
                infos = info
                for imagine, numerotare, legatura, numeepisod, data in match:
                    numeepisod = (htmlparser.HTMLParser().unescape(striphtml(numeepisod).decode('utf-8')).encode('utf-8')).strip()
                    numeepisod = unicode(numeepisod.strip(codecs.BOM_UTF8), 'utf-8')
                    numeepisod = ''.join(c for c in unicodedata.normalize('NFKD', numeepisod)
                                   if unicodedata.category(c) != 'Mn')
                    nume = '%s - %s - %s - %s' % (title, numerotare.strip(), numeepisod, data.strip())
                    try:
                        de = numerotare.strip().split('-')
                        test = de[1]
                    except: de = numerotare.strip().split('x')
                    infos['TVshowtitle'] = re.sub('\(.*?\)', '', title)
                    infos['Season'] = de[0]
                    infos['Episode'] = de[1]
                    infos['Title'] = '%s S%02dE%02d - %s' % (title, int(de[0].strip()), int(de[1].strip()), data.strip())
                    lists.append((nume, legatura, imagine, 'get_links', str(infos)))
        elif meniu == 'genuri':
            link = fetchData(url)
            regex = '''genres">(.+?)</nav>'''
            regex_cats = '''href=['"](.+?)['"](?:\s+>)?(.+?)<'''
            if link:
                for all_cat in re.findall(regex, link, re.DOTALL):
                    match = re.findall(regex_cats, all_cat, re.DOTALL)
                    if len(match) >= 0:
                        for legatura, nume in sorted(match, key=self.getKey):
                            lists.append((nume,legatura,'','filme', str(info)))

        return lists
              
