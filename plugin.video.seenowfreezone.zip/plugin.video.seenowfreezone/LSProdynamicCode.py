# -*- coding: utf-8 -*-
#$pyFunction
import re, requests
def GetLSProData(page_data,Cookie_Jar,m,):
  first_ip = re.findall("x_first_ip.+?'(.*?)'", page_data)[0]
  first_c = re.findall("x_first_c.+?'(.*?)'", page_data)[0]
  ket2 = re.findall("ket2.+?'(.*?)'", page_data)[0]
  first_ua = re.findall("x_first_ua.+?'(.*?)'", page_data)[0]
  preurl = 'http://tmg.ustreamix.com/'   # here is the server url which changed most of time
  url = preurl + 'stats.php?p=' + first_ip + '&C=' + first_c + '&Ket=' + ket2
  source = requests.get(url, headers = {'Referer': 'https://beta.ustreamix.com/stream.php?id=sky-select', 'User-Agent': first_ua, 'Accept': '*/*'}).text
  tok = re.findall('var jdtk="(.*?)"', source)[0]
  return preurl + 'tmg.m3u8?' + 'stream.php?id=sky-select' + '&token=' + tok
